// Previous imports remain the same...

export function ChatInterface() {
  // Previous state declarations remain the same...

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    setMessages(prev => [...prev, { type: 'user', text: inputText }]);

    try {
      let response = '';
      if (isLLMConnected && llmClient.current) {
        setIsProcessing(true);
        response = await llmClient.current.generateText(inputText);
      } else {
        // Generate response using probabilistic model
        response = DocumentProcessor.generateResponse(inputText);
        if (!response) {
          response = "Please upload a document first to train the response model.";
        }
      }

      setMessages(prev => [...prev, { type: 'system', text: response }]);

      if (isP2PConnected && p2pNetwork.current) {
        p2pNetwork.current.broadcast({
          type: 'CHAT_MESSAGE',
          message: { input: inputText, response }
        });
      }
    } catch (err) {
      setError('Failed to generate response. Please try again.');
    } finally {
      setIsProcessing(false);
      setInputText('');
    }
  };

  // Rest of the component remains the same...
}